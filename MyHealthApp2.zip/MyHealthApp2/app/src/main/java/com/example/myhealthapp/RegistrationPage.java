package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

public class RegistrationPage extends AppCompatActivity {
    EditText email, password;
    Button registerButton;
    TextInputLayout errorEmail, errorPassword;
    boolean isEmailValid, isPasswordValid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
        email = findViewById(R.id.editText_EmailAddress);
        password = findViewById(R.id.editText_Password);
        errorEmail = findViewById(R.id.error_email);
        errorPassword = findViewById(R.id.error_password);
        registerButton = findViewById(R.id.button_login);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Confirmation();
                startActivity(new Intent(RegistrationPage.this, ProfilePage.class));

            }

            private void Confirmation() {
                if (email.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                    errorEmail.setError(getResources().getString(R.string.error_invalid_email));
                    isEmailValid = false;
                } else  {
                    isEmailValid = true;
                    errorEmail.setErrorEnabled(false);
                }
                if (password.getText().toString().isEmpty() || password.getText().length() < 8) {
                    errorPassword.setError(getResources().getString(R.string.error_invalid_password));
                    isPasswordValid = false;
                } else  {
                    isPasswordValid = true;
                    errorPassword.setErrorEnabled(false);
                }
            }
        });

    }

}

