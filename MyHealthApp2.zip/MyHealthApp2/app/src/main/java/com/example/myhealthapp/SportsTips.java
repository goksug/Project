package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SportsTips extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports_tips);
        ListView sportslist = findViewById(R.id.list_view_sports_tips);

        String [] sportsTipsArray = {"Although aerobic exercise like brisk walking, running and biking is excellent forweight loss, many people tend to focus solely on cardio and don’t add strength training to their routines.",
                "If you are having trouble sticking to a workout routine or healthy eating plan, invite a friend to join you and help you stay on track.",
                "The great thing about choosing a workout routine is that there are endless possibilities",
                "Encourage cross-training and a variety of sports.",
                "Stretching is an important prevention technique that should become a habit for all athletes before starting an activity or sport.",
                "Athletes of all ages need to rest between practices, games and events.",
                "Protective equipment, like helmets, pads and shoes, are very important for injury prevention.",
                "The 10,000-hour rule explains how important practice is in anything we do. Therefore the more you practice the more you should learn and the better you will become.",






        };

        ArrayAdapter<String> sportsTipsAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,sportsTipsArray );
        sportslist.setAdapter(sportsTipsAdapter);
    }
}