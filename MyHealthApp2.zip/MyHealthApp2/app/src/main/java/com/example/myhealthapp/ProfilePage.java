package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class ProfilePage extends AppCompatActivity {
    private Button saveButton;
    private EditText name, surname, email, height, weight;
    private RadioButton female, other, male;
    private android.view.MenuItem MenuItem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);
        Button saveButton = findViewById(R.id.Button_SaveButton);
        EditText name = findViewById(R.id.editText_Name);
        EditText surname = findViewById(R.id.editText_Surname);
        EditText email = findViewById(R.id.editText_EmailAddress);
        EditText weight = findViewById(R.id.editText_Weight);
        EditText height = findViewById(R.id.editText_Height);


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

    }

    @Override
    protected void onResume()
    {
        super.onResume();
        EditText surname=findViewById(R.id.editText_Surname);
        EditText name=findViewById(R.id.editText_Name);
        EditText weight=findViewById(R.id.editText_Weight);
        EditText height=findViewById(R.id.editText_Height);
        EditText email=findViewById(R.id.editText_EmailAddress);
        RadioButton female=findViewById(R.id.RadioButton_FemaleButton);
        RadioButton male=findViewById(R.id.RadioButton_MaleButton);
        RadioButton other=findViewById(R.id.RadioButton_OtherButton);

        SharedPreferences prefS
                = getSharedPreferences("MySharedPref",
                MODE_WORLD_READABLE);
        String weight1 = prefS.getString("weight", "");
        String height1 = prefS.getString("height", "");
        String name1 = prefS.getString("name", "");
        String surname1 = prefS.getString("surname", "");
        String email1 = prefS.getString("email", "");

        Boolean male1 = false;
        Boolean female1 = false;
        Boolean other1 = false;

        male1=prefS.getBoolean("male",false);
        female1=prefS.getBoolean("female",false);
        other1=prefS.getBoolean("other",false);

        female.setChecked(female1);
        male.setChecked(male1);
        other.setChecked(other1);

        name.setText(name1);
        surname.setText(surname1);
        weight.setText(weight1);
        height.setText(height1);
        email.setText(email1);


    }

    @Override
    protected void onPause()
    {
        super.onPause();

        SharedPreferences sharedPreferences
                = getSharedPreferences("MySharedPref",
                MODE_PRIVATE);
        SharedPreferences.Editor editor
                = sharedPreferences.edit();
        editor.putString("weight",
                weight.getText().toString());
        editor.putString("height",
                height.getText().toString());
        editor.putString("email",
                email.getText().toString());
        editor.putString("name",
                name.getText().toString());
        editor.putString("surname",
                surname.getText().toString());

        editor.putBoolean("female",female.isChecked());
        editor.putBoolean("male",male.isChecked());
        editor.putBoolean("other",other.isChecked());



        editor.commit();
    }
}

