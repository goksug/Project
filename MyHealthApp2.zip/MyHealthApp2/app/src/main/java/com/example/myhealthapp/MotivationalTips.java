package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MotivationalTips extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivational_tips);
        ListView motivationalList = findViewById(R.id.motivational_tips_list_view);


        String [] motivationalTipsArray = {
                "Comparing yourself to models in magazines or celebrities on TV is not onlyunrealistic — it can also be unhealthy.",
                "There is intrinsic and extrinsic motivation. Try to be intrinsic which is to motivateyourself from within. If an athlete or human being draws their motivation from within, itmakes them unbreakable.",
                "Find a reason to love what you do or play then do it from your heart and soul",
                "There are always going to be more failures than championships. Do not give up onyour dream even when things seem negative. Do not let the negative thoughtmanifest. Pull from your motivation and passion and great things will happen!",
                "Your perceptions on things may not always be right. Learn to take criticism and toask for help when you need it.",
                "I don’t count my situps. I only start counting once it starts hurting.  -Muhammad Ali",
                "I’ve failed over and over again in my life. And that is why I succeed. – Michael Jordan",
                "The only way to prove you are a good sport is to lose. – Ernie Banks",
                "There may be people that have more talent than you, but there’s no excuse for anyone to work harder than you do. – Derek Jeter",
                "The road to Easy Street goes through the sewer. – John Madden",
                "To uncover your true potential you must first find your own limits and then you have to have the courage to blow past them. – Picabo Street"



        };


        ArrayAdapter<String> motTipsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, motivationalTipsArray);
        motivationalList.setAdapter(motTipsAdapter);
    }

}