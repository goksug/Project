package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Calculator extends AppCompatActivity {

    Button addIng,calculate;
    LinearLayout ingLayout, newLayout;
    CardView newIngCard;
    EditText name,count,calorie;
    TextView result;
    int i=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        Button addIng =findViewById(R.id.addButton);
        EditText calorie=findViewById(R.id.ingredientsCalorie);
        TextView result=findViewById(R.id.result);
        LinearLayout ingLayout=findViewById(R.id.linear);
        LinearLayout.LayoutParams layoutParams= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.HORIZONTAL);
        Button calculate=findViewById(R.id.calculateButton);
        addIng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ingLayout.addView(newIngCard);
                newLayout.addView(name);
                newLayout.addView(count);
                newIngCard.addView(newLayout,layoutParams);
                i++;

            }

        });
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double d = Double.parseDouble(String.valueOf(calorie));
                double base=0;
                double res;
                ;
                for (int j=i; j>1; j++){
                    double a=Double.parseDouble(String.valueOf(count));
                    base=base+a;
                }
                res= base+d;
                result.setText("Calorie of the recipe is "+res+".");


            }
        });



    }
}