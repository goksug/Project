package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Achievements extends AppCompatActivity {

    private ArrayList<ExampleItem> mExampleList;
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_achievements);

        createExampleList();
        buildRecyclerView();







        setTitle("Achievements Page");




    }



    public void changeItem(int position, String text) {
        mExampleList.get(position).changeText1(text);
        mAdapter.notifyItemChanged(position);

    }

    public void createExampleList() {
        mExampleList = new ArrayList<>();
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Run 5 km today.", "Line 2"));
        mExampleList.add(new ExampleItem(R.drawable.ic_audio,"Run 10 km today.", "Line 4"));
        mExampleList.add(new ExampleItem(R.drawable.ic_sun,"Run 15 km today", "Line 6"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Eat less than 2000 calories today", "Line 8"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Eat less than 1500 calories today", "Line 10"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Eat less than 1000 calories today.", "Line 12"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Get 1 hour more sleep today.", "Line 14"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Drink 3 liters of water.", "Line 16"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Do not eat chocolate for one week.", "Line 18"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Do not drink sugar drinks 1 month.", "Line 20"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Eat 5-10 hor paper every day.", "Line 22"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android,"Do 2 hour strength workout today.", "Line 24"));

    }

    public void buildRecyclerView(){
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(int position) {
                changeItem(position, "Congrats on completing a new achievement");

            }
        });

    }
}