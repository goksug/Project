package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;


public class HealthPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {
    private EditText drugs,weight,height,allergies,disease,cName,cPhone;
    private RadioButton YesW,NoW,YesO,NoO;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_page);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.blood_Type, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    @Override
    protected void onResume()
    {
        super.onResume();
        EditText drugs=findViewById(R.id.drugs);
        EditText weight=findViewById(R.id.editText_Weight);
        EditText height=findViewById(R.id.editText_Height);
        EditText allergies=findViewById(R.id.allergies);
        EditText disease=findViewById(R.id.disease);
        EditText cName=findViewById(R.id.editTextTextPersonName);
        EditText cPhone=findViewById(R.id.editTextPhone);
        RadioButton YesW=findViewById(R.id.Yes);
        RadioButton NoW=findViewById(R.id.No);
        RadioButton YesO=findViewById(R.id.Yes2);
        RadioButton NoO=findViewById(R.id.No2);
        Spinner spinner=findViewById(R.id.spinner);


        SharedPreferences prefS
                = getSharedPreferences("MySharedPref",
                MODE_WORLD_READABLE);
        String weight1 = prefS.getString("weight", "");
        String height1 = prefS.getString("height", "");
        String drugs1 = prefS.getString("drugs", "");
        String allergies1 = prefS.getString("allergies", "");
        String disease1 = prefS.getString("disease", "");
        String cName1 = prefS.getString("contactName", "");
        String cPhone1 = prefS.getString("contactPhone", "");
        Integer spinnerIndex= prefS.getInt("index",0);


        Boolean YesW1 = false;
        Boolean NoW1 = false;
        Boolean YesO1 = false;
        Boolean NoO1 = false;
        YesW1=prefS.getBoolean("WheelYes",false);
        NoW1=prefS.getBoolean("WheelNo",false);
        YesO1=prefS.getBoolean("OrganYes",false);
        NoO1=prefS.getBoolean("OrganNo",false);
        YesW.setChecked(YesW1);
        NoW.setChecked(NoW1);
        YesO.setChecked(YesO1);
        NoO.setChecked(NoO1);

        cName.setText(cName1);
        cPhone.setText(cPhone1);
        weight.setText(weight1);
        height.setText(height1);
        drugs.setText(drugs1);
        allergies.setText(allergies1);
        disease.setText(disease1);


    }

    @Override
    protected void onPause()
    {
        super.onPause();

        SharedPreferences sharedPreferences
                = getSharedPreferences("MySharedPref",
                MODE_PRIVATE);
        SharedPreferences.Editor editor
                = sharedPreferences.edit();
        editor.putString("weight",
                weight.getText().toString());
        editor.putString("height",
                height.getText().toString());
        editor.putString("drugs",
                drugs.getText().toString());
        editor.putString("allergies",
                allergies.getText().toString());
        editor.putString("disease",
                disease.getText().toString());
        editor.putString("contactName",
                cName.getText().toString());
        editor.putString("contactPhone",
                cPhone.getText().toString());
        editor.putBoolean("wheelYes",YesW.isChecked());
        editor.putBoolean("wheelNo",NoW.isChecked());
        editor.putBoolean("OrganYes",YesO.isChecked());
        editor.putBoolean("OrganNo",NoO.isChecked());
        editor.putInt("index", spinner.getSelectedItemPosition());


        editor.commit();
    }
}
