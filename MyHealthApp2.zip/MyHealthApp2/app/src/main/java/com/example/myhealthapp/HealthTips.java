package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class HealthTips extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_tips);
        ListView healthTips = findViewById(R.id.health_tips_list_view);

        String [] healthTipsArray = {"Athletes of all ages need to rest between practices, games and events.",
                "Encourage cross-training and a variety of sports",
                "Creating a healthier lifestyle means finding the time to put yourself first, even if you don’t think it’s possible.",
                "Snacking on unhealthy foods can cause weight gain.",
                "Vegetables are loaded with fiber and the nutrients your body craves.",
                "Drinking enough water throughout the day is good for overall health and can even help you maintain a healthy weight.",
                "Cooking more meals at home has been shown to promote weight loss and healthy eating",
                "Many people believe they must adopt a rigorous exercise routine to jumpstart weightloss.",
                "While consuming meals in front of your TV or computer may not seem like dietsabotage, eating while distracted may cause you to consume more calories and gain weight",
                "Added sugar,especially from sugary drinks, is a major reason for unhealthy weight gain and health problems like diabetes and heart disease",
                "Dont smoke",
                "Check your blood pressure regularly",
                "Get tested yearly about your health(check-up)",
                "Practice safe sex",
                " Clean your hands properly",


        };
        ArrayAdapter<String> healthTipsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,healthTipsArray);
        healthTips.setAdapter(healthTipsAdapter);
    }
}