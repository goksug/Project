package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NutritionTips extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition_tips);
        ListView nutritionTipsList = findViewById(R.id.nutrition_tips_list_view);


        String[] nutritionsTips = {
                "Skipping breakfast will not help you lose weight. You could miss out on essentialnutrients and you may end up snacking more throughout the day because you feel hungry ",
                "Eating at regular times during the day helps burn calories at a faster rate. It alsoreduces the temptation to snack on foods high in fat and sugar." ,
                "Fruit and veg are low in calories and fat, and high in fibre – 3 essential ingredients forsuccessful weight loss. They also contain plenty of vitamins and minerals.",
                "Foods containing lots of fibre can help keep you feeling full, which is perfect for losingweight. Fibre is only found in food from plants, such as fruit and veg, oats, wholegrain bread, brown rice and pasta, and beans, peas and lentils.",
                "Knowing how to read food labels can help you choose healthier options. Use thecalorie information to work out how a particular food fits into your daily calorie allowance on the weight loss plan.",
                "Using smaller plates can help you eat smaller portions. By using smaller plates andbowls, you may be able to gradually get used to eating smaller portions without going hungry. It takes about 20 minutes for the stomach to tell the brain it's full, so eatslowly and stop eating before you feel full.",
                "To avoid temptation, do not stock junk food – such as chocolate, biscuits, crisps andsweet fizzy drinks – at home. Instead, opt for healthy snacks, such as fruit, unsaltedrice cakes, oat cakes, unsalted or unsweetened popcorn, and fruit juice.",
                "Try to plan your breakfast, lunch, dinner and snacks for the week, making sure youstick to your calorie allowance. You may find it helpful to make a weekly shopping list",

        };

        ArrayAdapter<String> nutritionTipsAdapter= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,nutritionsTips);
        nutritionTipsList.setAdapter(nutritionTipsAdapter);

    }
}