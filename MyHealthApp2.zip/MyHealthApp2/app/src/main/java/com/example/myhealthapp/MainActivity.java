package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputLayout;



public class MainActivity extends AppCompatActivity {
    EditText email, password;
    boolean isEmailValid, isPasswordValid;
    TextInputLayout errorEmail, errorPassword;
    Button loginButton;
    TextView registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.editText_EmailAddress);
        password = findViewById(R.id.editText_Password);
        errorEmail = findViewById(R.id.error_email);
        errorPassword = findViewById(R.id.error_password);
        loginButton = findViewById(R.id.button_login);
        registration = findViewById(R.id.TextView_Register);



        loginButton.setOnClickListener(v -> {
            Confirmation();
            if(isEmailValid&&isPasswordValid){

                Intent intent = new Intent(getApplicationContext(), HomePage.class);
                startActivity(intent);
            }
        });

        registration.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), RegistrationPage.class);
            startActivity(intent);
        });
    }

    public void Confirmation() {
        if (email.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            errorEmail.setError(getResources().getString(R.string.error_message_email));
            isEmailValid = false;
        } else {
            isEmailValid = true;
            errorEmail.setErrorEnabled(false);
        }

        if (password.getText().toString().isEmpty() || password.getText().length() < 8) {
            errorPassword.setError(getResources().getString(R.string.error_invalid_password));
            isPasswordValid = false;
        } else {
            isPasswordValid = true;
            errorPassword.setErrorEnabled(false);
        }




    }



}