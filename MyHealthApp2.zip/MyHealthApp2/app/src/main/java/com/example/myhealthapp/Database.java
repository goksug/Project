package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

public class Database extends AppCompatActivity {

    Button btn_Add, ViewAll;
    EditText et_name, et_Age;
    Switch sw_Active;
    ListView lv_CustomerList;
    ArrayAdapter customerArrayAdapter;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        btn_Add = findViewById(R.id.btn_Add);
        ViewAll= findViewById(R.id.btn_ViewAll);
        et_name = findViewById(R.id.et_name);
        et_Age =findViewById(R.id.et_Age);
        sw_Active= findViewById(R.id.sw_Active);
        lv_CustomerList =findViewById(R.id.lv_CustomerList);

        ShowCustomersOnListView(databaseHelper);


        databaseHelper = new DatabaseHelper(Database.this);



        btn_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomerModel customerModel;

                try {
                    customerModel =new CustomerModel(-1,et_name.getText().toString(),Integer.parseInt(et_Age.getText().toString()),sw_Active.isChecked());
                    Toast.makeText(Database.this,customerModel.toString(),Toast.LENGTH_SHORT).show();
                }

                catch (Exception e) {
                    Toast.makeText(Database.this,"Error making customer",Toast.LENGTH_SHORT).show();
                    customerModel = new CustomerModel(-1, "error" , 0, false);

                }

                DatabaseHelper databaseHelper = new DatabaseHelper(Database.this);
                boolean success = databaseHelper.AddOne(customerModel);
                Toast.makeText(Database.this , "Success= " +success, Toast.LENGTH_SHORT).show();

                ShowCustomersOnListView(databaseHelper);


            }
        });

        ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper databaseHelper = new DatabaseHelper(Database.this);


                ShowCustomersOnListView(databaseHelper);
                //Toast.makeText(MainActivity.this, everyone.toString(), Toast.LENGTH_SHORT).show();


            }
        });




    }

    private void ShowCustomersOnListView(DatabaseHelper databaseHelper2) {
        customerArrayAdapter = new ArrayAdapter<CustomerModel>(Database.this, android.R.layout.simple_list_item_1, databaseHelper2.getEveryone());
        lv_CustomerList.setAdapter(customerArrayAdapter);
    }
}