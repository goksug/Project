package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class HomePage extends AppCompatActivity {
    int totalCalories = 0 ;
    EditText caloriesEditText;
    Button calculateButton,moreButton;
    TextView viewTextResults;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        findViews();


        moreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, MorePage.class));
            }
        });

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userCalories = caloriesEditText.getText().toString();
                double result = calculateCalories(userCalories);
                displayResults(result);
            }
        });


    }

    private void displayResults(double result) {

        DecimalFormat myFormatter = new DecimalFormat("0.00");
        String resultString = myFormatter.format(result);
        viewTextResults.setText(resultString);
    }

    private double calculateCalories(String userCalories) {

        totalCalories += Integer.parseInt(userCalories);
        return totalCalories;
    }


    private void findViews() {

        caloriesEditText = findViewById(R.id.edit_text_calories);
        calculateButton = findViewById(R.id.button_calculate);
        viewTextResults= findViewById(R.id.text_result);
        moreButton= findViewById(R.id.more);

    }


}
