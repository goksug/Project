package com.example.myhealthapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TipsPage extends AppCompatActivity {

    CardView sportsCard;
    CardView nutritionCard;
    CardView motivationalCard;
    CardView healthCard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips_page);
        sportsCard =findViewById(R.id.card_view);
        healthCard = findViewById(R.id.card_view_2);
        motivationalCard = findViewById(R.id.card_view_3);
        nutritionCard = findViewById(R.id.card_view_4);




        sportsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sportsCardIntent = new Intent(TipsPage.this, SportsTips.class);
                startActivity(sportsCardIntent);
            }
        });

        healthCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent healthCardIntent = new Intent(TipsPage.this, HealthTips.class);
                startActivity(healthCardIntent);
            }
        });

        motivationalCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent motivationalCardIntent = new Intent(TipsPage.this, MotivationalTips.class);
                startActivity(motivationalCardIntent);
            }
        });

        nutritionCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent nutritionCardIntent = new Intent(TipsPage.this, NutritionTips.class);
                startActivity(nutritionCardIntent);
            }
        });
    }
}